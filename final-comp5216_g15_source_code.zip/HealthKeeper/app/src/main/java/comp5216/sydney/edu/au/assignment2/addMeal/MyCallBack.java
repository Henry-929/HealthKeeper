package comp5216.sydney.edu.au.assignment2.addMeal;

import java.util.ArrayList;

public interface MyCallBack {
    void onCallback(ArrayList<UsersFood> arrayList);
}
