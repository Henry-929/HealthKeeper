package comp5216.sydney.edu.au.assignment2.news;

import android.graphics.drawable.Drawable;

public class NewsBean {
    public String title;
    public String des;
    public Drawable icon;
    public String news_url;
}
