package comp5216.sydney.edu.au.assignment2.main;

public interface WeightCallBack {
    void onCallback(String weight);
}
